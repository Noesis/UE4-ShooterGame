var regions = {
  "All": "index_All.html",
  "0": "index_JP.html",
  "1": "index_US.html",
  "2": "index_EU.html",
  "3": "index_EU.html",
};
